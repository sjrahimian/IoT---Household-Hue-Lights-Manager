var searchData=
[
  ['brightnessfunction',['brightnessFunction',['../classMainFile.html#ae0fc8c88e542b61aa5dc5b2f36685b93',1,'MainFile']]],
  ['brightnessgroupfunction',['brightnessGroupFunction',['../classMainFile.html#a48d89d2be2e6536e61ea90ff421146d3',1,'MainFile']]],
  ['bulbobjects',['bulbObjects',['../classFunction.html#a2f8c8247b2f7f7ee8747fa63efeb2d30',1,'Function']]],
  ['bulbtests',['bulbTests',['../classFunction.html#a256e19fefab4ac9b4022f5b2f1c2fca4',1,'Function']]]
];
