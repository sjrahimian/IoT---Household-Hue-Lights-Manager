var searchData=
[
  ['rave',['rave',['../classMainFile.html#a3525326f33d097753aedf19c2b658843',1,'MainFile']]],
  ['registerprofile',['RegisterProfile',['../classLogin.html#ac9967a73022c749249f6cc1e12e3f7ee',1,'Login']]]
];
