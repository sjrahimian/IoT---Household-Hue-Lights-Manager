var searchData=
[
  ['deletegroup',['deleteGroup',['../classMainFile.html#ae53c6b5715dcc364d8a82cb20771c7cc',1,'MainFile']]],
  ['deleteschedfunc',['deleteSchedFunc',['../classMainFile.html#ae79f424340daf76dfffd3e7afb4d0b5d',1,'MainFile']]]
];
