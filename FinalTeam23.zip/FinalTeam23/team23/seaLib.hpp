//File: seaLib.hpp
/* Sama Rahimian
 * cs3307a - Fall 2017
 * Group Project -- Team 23
 */

#ifndef SEALIB_HPP
#define SEALIB_HPP

// standard C++ libraries
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <typeinfo>
#include <vector>

#endif
